package com.example.pro_bigdata

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
