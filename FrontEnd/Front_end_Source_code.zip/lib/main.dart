import 'package:flutter/material.dart';
import 'package:pro_bigdata/menu.dart';


//List<CameraDescription>? cameras;

Future<void> main() async {
  runApp(
    const MaterialApp(
      home: menu(),
      debugShowCheckedModeBanner: false,
    ),
  );
}

class hashtag2count {
  String hashtag;
  int count;
  hashtag2count(
    this.hashtag,
    this.count,
  );
}

class score_time {
  String time;
  double score;
  score_time(
    this.time,
    this.score,
  );
}
