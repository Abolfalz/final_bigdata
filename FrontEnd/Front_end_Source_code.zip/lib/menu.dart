import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'main.dart';
import 'package:http/http.dart' as http;

class menu extends StatefulWidget {
  const menu({Key? key}) : super(key: key);

  @override
  State<menu> createState() => _menuState();
}

class _menuState extends State<menu> {
  List<hashtag2count> h2c = [
    hashtag2count('بورس', 10),
    hashtag2count('سهام', 12),
    hashtag2count('نفت', 16),
    hashtag2count('رمزارز', 20),
    hashtag2count('بیت کوین', 18),
  ];

  List<score_time> s2t = [
    score_time(DateTime.timestamp().toString(), 0),
    score_time(DateTime.timestamp().toString(), 0),
    score_time(DateTime.timestamp().toString(), 0),
    score_time(DateTime.timestamp().toString(), 0),
    score_time(DateTime.timestamp().toString(), 0),
  ];

  List<hashtag2count> h = [];
  String last_text = 'سلام، این یک خبر تست است';

  late List<dynamic> value;
  List<hashtag2count> iss = [];

  Future get_inf() async {
    value = [];
    iss = [];
    var result = await http.get(
      Uri.parse('http://127.0.0.1:5000/inf'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
    );
    List<dynamic> dataList = jsonDecode(result.body);
    print(dataList);
    h2c = [];

    setState(() {
      last_text = dataList[1];

      h2c.add(dataList[0].length > 0 ? hashtag2count(dataList[0][0][0], dataList[0][0][1]) : hashtag2count('', 0));
      h2c.add(dataList[0].length > 1 ? hashtag2count(dataList[0][1][0], dataList[0][1][1]) : hashtag2count('', 0));
      h2c.add(dataList[0].length > 2 ? hashtag2count(dataList[0][2][0], dataList[0][2][1]) : hashtag2count('', 0));
      h2c.add(dataList[0].length > 3 ? hashtag2count(dataList[0][3][0], dataList[0][3][1]) : hashtag2count('', 0));
      h2c.add(dataList[0].length > 4 ? hashtag2count(dataList[0][4][0], dataList[0][4][1]) : hashtag2count('', 0));
      h2c.add(dataList[0].length > 5 ? hashtag2count(dataList[0][5][0], dataList[0][5][1]) : hashtag2count('', 0));
      h2c.add(dataList[0].length > 6 ? hashtag2count(dataList[0][6][0], dataList[0][6][1]) : hashtag2count('', 0));
      h2c.add(dataList[0].length > 7 ? hashtag2count(dataList[0][7][0], dataList[0][7][1]) : hashtag2count('', 0));
      h2c.add(dataList[0].length > 8 ? hashtag2count(dataList[0][8][0], dataList[0][8][1]) : hashtag2count('', 0));
      h2c.add(dataList[0].length > 9 ? hashtag2count(dataList[0][9][0], dataList[0][9][1]) : hashtag2count('', 0));

      h2c.add(dataList[0].length > 10 ? hashtag2count(dataList[0][10][0], dataList[0][10][1]) : hashtag2count('', 0));
      h2c.add(dataList[0].length > 11 ? hashtag2count(dataList[0][11][0], dataList[0][11][1]) : hashtag2count('', 0));
      h2c.add(dataList[0].length > 12 ? hashtag2count(dataList[0][12][0], dataList[0][12][1]) : hashtag2count('', 0));
      h2c.add(dataList[0].length > 13 ? hashtag2count(dataList[0][13][0], dataList[0][13][1]) : hashtag2count('', 0));
      h2c.add(dataList[0].length > 14 ? hashtag2count(dataList[0][14][0], dataList[0][14][1]) : hashtag2count('', 0));

      if (s2t.length > 4) {
        s2t.removeAt(0);
        s2t.add(score_time(DateTime.now().toString(), dataList[2]));
      }
    });
  }

  initState() {
    int i = 0;
    Timer.periodic(
      const Duration(seconds: 4),
      (timer) {
        get_inf();
      },
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var h = MediaQuery.of(context).size.height;
    var w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        toolbarHeight: h * 0.08,
        title: Text(
          'نمودار لحظه ای',
          textAlign: TextAlign.end,
          style: TextStyle(
            fontSize: w * 0.028,
            fontFamily: 'yekan',
            color: Colors.white,
          ),
        ),
      ),
      body: Container(
        height: h,
        width: w,
        child: Container(
          child: Stack(
            children: [
              Container(
                alignment: Alignment.topLeft,
                color: Colors.white12,
                child: Container(
                  height: h * 0.52,
                  width: w * 0.34,
                  margin: EdgeInsets.only(
                    top: h * 0.18,
                    left: w * 0.1,
                  ),
                ),
              ),
              Container(
                alignment: Alignment.topRight,
                child: Container(
                  margin: EdgeInsets.only(
                    top: h * 0.05,
                    right: w * 0.018,
                  ),
                  height: h * 0.8,
                  width: w * 0.25,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3),
                        spreadRadius: 3,
                        blurRadius: 5,
                        offset: Offset(0, 3),
                      ),
                    ],
                    color: Colors.white,
                    borderRadius: const BorderRadius.all(
                      Radius.circular(
                        10,
                      ),
                    ),
                  ),
                  child: Stack(
                    children: [
                      Container(
                        alignment: Alignment.topRight,
                        child: Container(
                          margin: EdgeInsets.only(
                            top: h * 0.035,
                            right: w * 0.02,
                          ),
                          child: Text(
                            'خبر',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: w * 0.015,
                              fontFamily: 'yekan',
                              color: Colors.blue,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.topRight,
                        child: Container(
                          width: w * 0.03,
                          margin: EdgeInsets.only(
                            top: h * 0.075,
                            right: w * 0.018,
                          ),
                          child: const LinearProgressIndicator(
                            backgroundColor: Colors.transparent,
                            color: Colors.blueAccent,
                          ),
                        ),
                      ),
                      Container(
                        //color: Colors.lightBlue,
                        height: h * 0.75,
                        width: w * 0.85,
                        margin: EdgeInsets.only(
                          top: h * 0.095,
                          left: w * 0.015,
                          right: w * 0.015,
                          bottom: h * 0.4,
                        ),
                        child: Container(
                          child: Text(
                            last_text,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: w * 0.01,
                              fontFamily: 'yekan',
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          margin: const EdgeInsets.only(
                            top: 10,
                            left: 20,
                            right: 20,
                            bottom: 10,
                          ),
                          height: h * 0.39,
                          width: w * 0.8,
                          //color: Colors.deepOrange,
                          child: Stack(
                            children: [
                              Container(
                                alignment: Alignment.topRight,
                                child: Container(
                                  margin: EdgeInsets.only(
                                    top: h * 0.02,
                                    right: w * 0.012,
                                  ),
                                  child: Text(
                                    'ترس و طمع',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: w * 0.01,
                                      fontFamily: 'yekan',
                                      color: Colors.amber,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                alignment: Alignment.topRight,
                                child: Container(
                                  width: w * 0.047,
                                  margin: EdgeInsets.only(
                                    top: h * 0.050,
                                    right: w * 0.01,
                                  ),
                                  child: const LinearProgressIndicator(
                                    backgroundColor: Colors.transparent,
                                    color: Colors.amber,
                                  ),
                                ),
                              ),
                              Container(
                                child: Container(
                                  margin: EdgeInsets.only(
                                    top: h * 0.07,
                                    left: 10,
                                    right: 10,
                                    bottom: 20,
                                  ),
                                  child: Container(
                                    child: Container(
                                      child: SfCartesianChart(
                                        primaryXAxis: CategoryAxis(),
                                        series: <ChartSeries>[
                                          // Renders line chart
                                          LineSeries<score_time, String>(
                                              dataSource: s2t,
                                              xValueMapper: (score_time data, _) => data.time,
                                              yValueMapper: (score_time data, _) => data.score),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                //alignment: Alignment.topLeft,
                alignment: Alignment.topLeft,
                child: Container(
                  height: h * 0.8,
                  width: w * 0.7,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3),
                        spreadRadius: 3,
                        blurRadius: 5,
                        offset: Offset(0, 3),
                      ),
                    ],
                    color: Colors.white,
                    borderRadius: const BorderRadius.all(
                      Radius.circular(
                        10,
                      ),
                    ),
                  ),
                  margin: EdgeInsets.only(
                    top: h * 0.05,
                    left: w * 0.02,
                  ),
                  child: Stack(
                    children: [
                      Container(
                        child: Container(
                          alignment: Alignment.topCenter,
                          margin: EdgeInsets.only(
                            top: h * 0.12,
                            right: 10,
                            left: 10,
                          ),
                          height: h * 0.65,
                          width: w,
                          color: Colors.white,
                          child: SfCartesianChart(
                            primaryXAxis: CategoryAxis(),
                            series: <ChartSeries<hashtag2count, String>>[
                              ColumnSeries<hashtag2count, String>(
                                  dataSource: h2c,
                                  xValueMapper: (hashtag2count data, _) => data.hashtag,
                                  yValueMapper: (hashtag2count data, _) => data.count,
                                  borderRadius: const BorderRadius.only(topLeft: Radius.circular(12), topRight: Radius.circular(12)),
                                  dataLabelSettings: DataLabelSettings(isVisible: true),
                                  color: Colors.green)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.topCenter,
                        child: Container(
                          margin: EdgeInsets.only(top: h * 0.025),
                          child: Text(
                            'نمودار هشتگ / تعداد',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: w * 0.018,
                              fontFamily: 'yekan',
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.topRight,
                        child: Container(
                          margin: EdgeInsets.only(
                            top: h * 0.035,
                            right: w * 0.02,
                          ),
                          child: Text(
                            'زنده',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: w * 0.015,
                              fontFamily: 'yekan',
                              color: Colors.redAccent,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.topRight,
                        child: Container(
                            width: w * 0.032,
                            margin: EdgeInsets.only(
                              top: h * 0.075,
                              right: w * 0.02,
                            ),
                            child: const LinearProgressIndicator(
                              backgroundColor: Colors.transparent,
                              color: Colors.redAccent,
                            )),
                      ),
                      //       ),),),)
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
